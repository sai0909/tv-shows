// Api utilities
import moxios from 'moxios'
import api from '@/api'

// Utilities
import { __createMocks as createStoreMocks } from '../store/__mocks__/index'
import shows from '@/store/modules/shows'

jest.mock('@/store')

describe('Store management', () => {
  let storeMocks

  beforeEach(() => {
    storeMocks = createStoreMocks()
  })

  afterEach(() => {
    jest.resetModules()
    jest.clearAllMocks()
  })

  describe('Actions', () => {
    beforeEach(() => {
      moxios.install(api)
    })

    afterEach(() => {
      moxios.uninstall(api)
    })

    it('when pullTvShows is call should commit SET_SHOWS and SET_GENRES mutations', async () => {
      const commit = jest.fn()
      const showsData = [{
        id: 2,
        name: 'Love Actually',
        genres: ['Drama', 'Science-Fiction', 'Thriller'],
        rating: { average: 9.5 }
      },
      {
        id: 3,
        name: 'GOT',
        genres: ['Drama', 'Thriller'],
        rating: { average: 8.5 }
      }]
      shows.actions.pullTvShows({ commit }).then(() => {
        expect(commit).toHaveBeenCalledWith('SET_SHOWS', showsData)
        expect(commit).toHaveBeenCalledWith('SET_GENRES', true)
      }).catch((error) => { console.log(error) })
    })

    it('when pullTvShow is call should commit SET_SHOW_INFO mutation', async () => {
      const commit = jest.fn()

      shows.actions.pullTvShow({ commit }, 1).then(() => {
        expect(commit).toHaveBeenCalledWith('SET_SHOW_INFO', true)
      }).catch((error) => { console.log(error) })
    })

    it('when pullTvShowImages is call should commit SET_SHOW_IMAGES mutation', done => {
      const commit = jest.fn()

      shows.actions
        .pullTvShowImages({ commit }, 1)
        .then(() => {
          expect(commit).toHaveBeenCalledWith('SET_SHOW_IMAGES', true)
        }).catch((error) => { console.log(error) })
        .finally(done())
    })
  })

  describe('Mutations', () => {
    it('should change the shows state', () => {
      shows.mutations.SET_SHOWS(storeMocks.showsState, [
        {
          id: 2,
          name: 'Love Actually',
          genres: ['Drama', 'Science-Fiction', 'Thriller'],
          rating: { average: 6.5 }
        }

      ])
      expect(storeMocks.showsState.shows[0].name).toEqual('Love Actually')
    })

    it('should change the genres state', () => {
      shows.mutations.SET_GENRES(storeMocks.showsState, ['Romance'])
      expect(storeMocks.showsState.genres).toEqual(['Romance'])
    })

    it('should change the show info state', () => {
      shows.mutations.SET_SHOW_INFO(storeMocks.showsState, {
        id: 2,
        name: 'Love Actually'
      })
      expect(storeMocks.showsState.showDetail.name).toEqual('Love Actually')
    })

    it('should change the show images state to an empty array', () => {
      shows.mutations.SET_SHOW_IMAGES(storeMocks.showsState, [])
      expect(storeMocks.showsState.showImages).toEqual([])
    })
  })
})
