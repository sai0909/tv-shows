<template>
  <div class="d-flex align-center justify-center">
    <v-progress-circular
      :size="50"
      :width="6"
      color="primary"
      indeterminate
    ></v-progress-circular>
  </div>
</template>

<style scoped lang="scss">
div {
  height: 100%;
}
</style>
